import React from 'react';
function display(){
    alert("Message from Javascript alert!");
    console.log("Message to developer");
}
const Firstd1c1 = () => {
    return(
        <div>
        
        <h1>Let we see the output of JAVASCRIPT</h1>
        <br></br>
        <button onClick={display}>click</button>
        </div>
    );
};
export default Firstd1c1;  