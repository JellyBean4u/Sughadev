import React from "react";

const Firstd1c3 = () => {
    return (

     <div>
        <p>This is World Functional Component</p>
    </div>
    );
};
export default Firstd1c3;