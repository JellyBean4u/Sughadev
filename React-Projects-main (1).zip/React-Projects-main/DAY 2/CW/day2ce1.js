import React from 'react';

const Firstd2c1 = () => {
    return(
        <div>
            <h1>Hello, World!</h1>
        </div>
    );
};
export default Firstd2c1;
