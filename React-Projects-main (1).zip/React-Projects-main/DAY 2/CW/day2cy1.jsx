import React from "react";

 const Firstd2cy1 = () =>{
    return(
    <div style=
    {{textAlign:'center',
    alignItems:'center',
    display:'flex',
    flexDirection:'column',
    justifyContent:'center',
    backgroundColor:'lavender',
    height:'100vh'}}>
        <h1>Smile Component</h1>
        <p style={{fontWeight:'bold'}}>It is a functional Component</p>
        <img src="https://static.vecteezy.com/system/resources/previews/003/660/834/original/happy-smile-emoticon-expression-free-vector.jpg" alt="emoji" width={'500px'}/>
    </div>
    )
 }
 export default Firstd2cy1; 
